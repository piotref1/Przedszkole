package Classes;

public class Cook {

    public void setInformationAboutMenu(Menu menu, String typeOfMeal, String composition) {
        menu.setInformationAboutMenu(typeOfMeal,composition);
    }
    public void checkInformationAboutAllergens() {

    }

}

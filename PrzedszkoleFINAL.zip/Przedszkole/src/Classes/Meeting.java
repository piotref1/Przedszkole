package Classes;

public interface Meeting {
    String checkInformationAboutMeeting();
}

package Database;

public class DatabaseInsert {
}
